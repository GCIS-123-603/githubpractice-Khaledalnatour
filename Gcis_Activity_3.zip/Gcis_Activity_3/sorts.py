import arrays
import array_utils
import insertion

"""
Defining a function which performs quick insertion sort
"""

def quick_insertion_sort(an_array):
    if len(an_array) < 1:
        return arrays.Array(0)
    elif len(an_array) == 1:
        return an_array
    elif 2 <= len(an_array) <= 25:
        return insertion.insertion_sort(an_array)
    else:
        pivot = int(len(an_array) / 2)
        less, same, more = partition(pivot, an_array)
        return array_utils.cat_array(array_utils.cat_array(quick_insertion_sort(less), same), quick_insertion_sort(more))

"""
Defining a function to perform partition for quick insertion sort
"""

def partition(pivot, an_array):
    length = len(an_array)
    llen, slen, mlen = 0, 0, 0
    for index in range(length):
        if an_array[index] == an_array[pivot]:
            slen += 1
        elif an_array[index] < an_array[pivot]:
            llen += 1
        elif an_array[index] > an_array[pivot]:
            mlen += 1
    less, same, more = arrays.Array(llen), arrays.Array(slen), arrays.Array(mlen)
    i1, i2, i3 = 0, 0, 0
    for index in range(length):
        if an_array[index] < an_array[pivot]:
            less[i1] = an_array[index]
            i1 = i1 + 1
        elif an_array[index] > an_array[pivot]:
            more[i2] = an_array[index]
            i2 = i2 + 1
        else:
            same[i3] = an_array[index]
            i3 = i3 + 1
    return less, same, more

