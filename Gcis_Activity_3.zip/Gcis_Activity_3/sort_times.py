#Done by Khaled, Daniyal and Janeeta

import array_utils
import insertion
import merge
import quick
import sorts
import plotter
import time

"""
A function that implements the various sorts 
and times it
"""

def sort_function_timer(sort_function, an_array):
    if sort_function == "insertion":
        begin = time.perf_counter()
        insertion.insertion_sort(an_array)
        end = time.perf_counter()
    elif sort_function == "merge":
        begin = time.perf_counter()
        merge.merge_sort(an_array)
        end = time.perf_counter()
    elif sort_function == "quick":
        begin = time.perf_counter()
        quick.quick_sort(an_array)
        end = time.perf_counter()
    elif sort_function == "quickinsertion":
        begin = time.perf_counter()
        sorts.quick_insertion_sort(an_array)
        end = time.perf_counter()
    else:
        print("Invalid sort function name")
    totalTime = end - begin
    print(totalTime)
    return totalTime

""" 
Defining a function that sorts random arrays
"""

def plot_sort_time_using_random_arrays(sort_function):
    print("--", sort_function, "--")
    plotter.new_series()
    for i in range(len(SIZES)):
        an_array = array_utils.random_array(SIZES[i])
        plotter.add_data_point(sort_function_timer(sort_function, an_array))

"""
Defining a function which sorts an already sorted array
"""

def plot_sort_time_using_sorted_z(sort_function):
    print("--", sort_function, "--")
    plotter.new_series()
    for i in range(len(SIZES)):
        an_array = array_utils.random_array(SIZES[i])
        sorted_array = merge.merge_sort(an_array)
        plotter.add_data_point(sort_function_timer(sort_function, sorted_array))

"""
Function for plotting the varoius sorts- insertion, merge and quick sort
"""

def plotting():
    plotter.init("Sorting - Time Complexities", "Size of the Array", "Total Time")
    sorting = ["insertion", "merge", "quick"]
    for i in sorting:
        plot_sort_time_using_random_arrays(i)

"""
Defining a function which plots for insertion, merge and quick-insertion sort
"""

def plotting_quick_insertion():
    plotter.init("Sorting - Time Complexities", "Size of the Array", "Total Time")
    sorting = ["insertion", "merge", "quickinsertion"]
    for i in sorting:
        plot_sort_time_using_random_arrays(i)

def main():
    global SIZES
    SIZES = array_utils.range_array(200, 2300, 300)
    plotting_quick_insertion()
    plotter.plot()
    input()

if __name__ == "__main__":
    main()
