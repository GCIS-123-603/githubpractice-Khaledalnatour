def swap(an_array,a,b):
    temp = an_array[a]
    an_array[a]=an_array[b]
    an_array[b]=temp
    return an_array

def shift(an_array,index):
    while index>0:
        if (an_array[index] < an_array[index-1]):
            swap(an_array,index,index-1)
        index = index-1
    return an_array

def insertion_sort(an_array):
    for each_index in range(len(an_array)):
        shift(an_array,each_index)
    return an_array

