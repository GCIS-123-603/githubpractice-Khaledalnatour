import arrays

def merge_sort(an_array):
    if len(an_array) == None:
        return an_array
    elif len(an_array) == 1:
        return an_array
    else:
        half1,half2 = split(an_array)
        if abs(len(half1)-len(half2))>1:
            return -1
        else:
            return merge(merge_sort(half1),merge_sort(half2))

def split(an_array):
    half2 = arrays.Array((len(an_array)//2))
    half1 = arrays.Array(len(an_array) - len(half2))
    i1 = 0
    i2 = 0
    for index in range(len(an_array)):
        if index % 2 == 0:
            half1[i1] = an_array[index]
            i1+=1
        elif index % 2 == 1:
            half2[i2] = an_array[index]
            i2+=1
    return half1, half2

def merge(sorted1, sorted2):
    result = arrays.Array(len(sorted1)+len(sorted2))
    i1 = 0
    i2 = 0
    index = 0
    while i1 < len(sorted1) and i2 < len(sorted2):
        if sorted1[i1] <= sorted2[i2]:
            result[index] = sorted1[i1]
            i1 = i1 + 1
            index+=1
        else:
            result[index] = sorted2[i2]
            i2 = i2 + 1
            index+=1
    if i1 < len(sorted1):
        while i1 < len(sorted1):
            result[index] = sorted1[i1]
            i1=i1+1
            index+=1
    elif i2 < len(sorted2):
        while i2 < len(sorted2):
            result[index] = sorted2[i2]
            i2=i2+1
            index+=1
    return result