import turtle

def draw_square(color):
    turtle.fillcolor(color)
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def row_type_1():
    for i in range(10):
        draw_square("red")
        turtle.forward(30)
        draw_square("black")
        turtle.forward(30)

def row_type_2():
    for i in range(10):
        draw_square("black")
        turtle.forward(30)
        draw_square("red")
        turtle.forward(30)

def row_reset():
    turtle.right(90)
    turtle.forward(30)
    turtle.left(90)
    turtle.backward(600)

def main():
    turtle.penup()
    turtle.speed(0)
    turtle.goto(-300,300)
    turtle.pendown()
    for i in range(10):
        row_type_1()
        row_reset()
        row_type_2()
        row_reset()
    input("Press enter to terminate...")
    

    

main()