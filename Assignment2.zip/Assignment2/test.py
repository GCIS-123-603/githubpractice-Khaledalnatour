file1 = open("drawing01.txt","r")
a = file1.readlines()
print(len(a))
# for i in a:
#     i = i.strip()
#     print(len(i))