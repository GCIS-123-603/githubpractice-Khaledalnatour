import turtle

def draw_black_pixel():
    turtle.fillcolor("black")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_white_pixel():
    turtle.fillcolor("white")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_red_pixel():
    turtle.fillcolor("red")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_yellow_pixel():
    turtle.fillcolor("yellow")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_orange_pixel():
    turtle.fillcolor("orange")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_green_pixel():
    turtle.fillcolor("green")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_yellowgreen_pixel():
    turtle.fillcolor("yellowgreen")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_sienna_pixel():
    turtle.fillcolor("sienna")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_tan_pixel():
    turtle.fillcolor("tan")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_gray_pixel():
    turtle.fillcolor("gray")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()

def draw_darkgray_pixel():
    turtle.fillcolor("darkgray")
    turtle.begin_fill()
    for i in range (4):
        turtle.forward(30)
        turtle.right(90)
    turtle.end_fill()