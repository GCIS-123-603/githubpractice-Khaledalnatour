import paint
import turtle


def draw_square(number):
    if number == "0":
        paint.draw_black_pixel()
    elif number == "1":
        paint.draw_white_pixel()
    elif number == "2":
        paint.draw_red_pixel()    
    elif number == "3":
        paint.draw_yellow_pixel()
    elif number == "4":
        paint.draw_orange_pixel()
    elif number == "5":
        paint.draw_green_pixel()
    elif number == "6":
        paint.draw_yellowgreen_pixel()
    elif number == "7":
        paint.draw_sienna_pixel()
    elif number == "8":
        paint.draw_tan_pixel()        
    elif number == "9":
        paint.draw_gray_pixel()
    elif number == "A":
        paint.draw_darkgray_pixel()
    else:
        return(False)

def Color_fill_checker(number):
    if number in "0123456789A":
        draw_square(number)
        turtle.forward(30)
        return True
    else:
        print("False")
        return False

def select_number(row):
    for i in range(len(row)):
        a = row[i]
        if Color_fill_checker(a) == False:
            break
    print("True")

def rowreset():
    turtle.right(90)
    turtle.forward(30)
    turtle.left(90)
    turtle.backward(30*width)

def file_reader():
    global text
    file1 = open(text_filename,"r")
    text = file1.readlines()

def size():
    with open(text_filename, "r") as file1:
        a = file1.readlines()
    with open(text_filename, "r") as file1:
        row = file1.readline()
        row = row.strip()
    return(len(row),len(a))
    file1.close()

def turtle_enviornment():
    global height
    global width

    turtle.speed(0)
    turtle.tracer(10)
    turtle.penup()
    width, height = size()
    turtle.goto(-15*width,15*height)
    turtle.pendown()

def drawer():
    for i in text:
        row = i.strip()
        select_number(row)
        rowreset()

def user_input():
    global text_filename
    text_filename = input("Type the text file you want to draw: ")

def main(): 
    user_input()
    turtle_enviornment()
    file_reader()
    drawer()
    input("")

main()